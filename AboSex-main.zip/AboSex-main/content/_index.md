---
description: Abogadxs por los derechos sexuales
intro_image: images/illustrations/asterisco.jpg
intro_image_absolute: true
intro_image_hide_on_mobile: true
meta_title: Hugo Serif Theme
title: Homepage
---

# AboSex.
## Bienvenid*s a nuestro sitio

Somos un grupo interdisciplinario comprometido con la promoción de los derechos de la diversidad sexual. Hacemos activismo legal y político.
