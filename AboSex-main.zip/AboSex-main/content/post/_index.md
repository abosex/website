---
description: Lo que hicimos y lo que queda por hacer
intro_image: images/illustrations/decimos.jpg
intro_image_absolute: true
intro_image_hide_on_mobile: false
title: Publicaciones
---

# Notas y publicaciones

En esta sección compartimos nuestras demandas y otros documentos de interés.


> :mag_right: Buscar notas por [Etiqueta](../tags/)

