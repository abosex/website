---
description: Lo que hicimos y lo que queda por hacer
intro_image: images/illustrations/hacemos.jpg
intro_image_absolute: true
intro_image_hide_on_mobile: false
title: Nuestro activismo
---

# Nuestros logros y objetivos

Desde 2013 estamos comprometidos con la construcción de un mundo más igualitario, especialmente en lo que a la protección de las diversidades sexuales se refiere. 

Hemos asistido a importantes avances, pero todavía queda mucho por hacer.
