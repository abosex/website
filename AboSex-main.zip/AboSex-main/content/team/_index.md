---
intro_image: images/team/team.jpg
intro_image_absolute: false
intro_image_hide_on_mobile: false
title: Equipo
---

# ¡Conocé a nuestros integrantes!

Somos un equipo interdisciplinario, que integran profesionales provenientes del derecho y las ciencias sociales y humanas con interés en aportar desde los propios saberes y experiencias.
