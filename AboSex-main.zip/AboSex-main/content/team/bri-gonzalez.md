---
date: "2018-11-19T10:47:58+10:00"
draft: false
image: images/team/nopic.png
jobtitle: Abogado
promoted: true
title: Braian González
weight: 1
---

30 años, abogado de la Facultad de Derecho de la UBA, empleado del Poder Judicial de la Nación. Trabajé en una Fiscalía de Violencia de Género, e integré la Comisión Organizadora de la I Marcha del Orgullo de Escobar (mi ciudad de origen). Soy parte de la Comisión de Litigios de AboSex, y estoy estudiando el Profesorado de Ciencias Jurídicas.