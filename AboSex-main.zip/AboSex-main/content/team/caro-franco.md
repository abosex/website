---
date: "2018-12-20T13:44:30+10:00"
draft: true
image: images/team/carofranco.jpeg
jobtitle: Comunicadora / Politóloga
promoted: true
title: Carolina V. Franco Häntzsch
weight: 3
---

Comunicadora (UBA) y politóloga (en proceso: UTDT). Becaria en CONICET. Intento de investigadora. Docente. Activista. 
