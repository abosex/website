---
date: "2018-12-20T13:44:30+10:00"
draft: true
image: images/team/emi.jpg
jobtitle: Abogad0
promoted: true
title: Emiliano Litardo
---

Abogado (UBA), docente en FDerecho (UBA) y Maestría de Estudios y Politicas de Género (UNTREF), activista legal miembro de Abogadxs por los Derechos Sexuales y de la Asociación de Lucha por la Identidad Travesti Transexual, fue parte del Frente Nacional por la Ley de Identidad de Género y de la Comunidad Homosexual Argentina (CHA), escribe sobre derecho y género, bordador.
