---
date: "2018-11-19T10:47:58+10:00"
draft: false
image: images/team/nopic.png
jobtitle: Abogado
promoted: true
title: Iñaki Regueiro De Giacomi
weight: 1
---

Abogado (Universidad de Buenos Aires). Maestrando en Derecho Internacional de los Derechos Humanos (Universidad de Buenos Aires). Maestría en Leyes (LL.M.) especializada en discapacidad por la Universidad de Syracuse, EE.UU. Trabaja temáticas relativas a Derechos LGBTI y Derechos de Personas con Discapacidad.

