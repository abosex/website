---
date: "2018-12-20T13:44:30+10:00"
draft: true
image: images/team/sofi.jpg
jobtitle: Abogada
promoted: true
title: Sofía Novillo Funes
weight: 3
---

Abogada (Universidad Nacional de Córdoba). Maestranda en Derecho Internacional de los Derechos Humanos por la Universidad de Buenos Aires.
